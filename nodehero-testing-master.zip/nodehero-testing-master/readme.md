## nodehero-testing

#### run it

```
npm install
npm test
```
